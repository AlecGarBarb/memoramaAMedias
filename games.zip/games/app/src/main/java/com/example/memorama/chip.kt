package com.example.memorama

data class Chip(val idImage: Int)

